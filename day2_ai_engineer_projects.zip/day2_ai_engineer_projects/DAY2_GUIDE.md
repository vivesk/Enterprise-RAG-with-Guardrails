# Day 2 Project Guide

## Primary project
Enterprise Research & Analysis Agent.

It combines agent routing, controlled tools, FastAPI, Streamlit, structured outputs, human approval, Docker and tests.

## Demo sequence
1. Start Ollama.
2. Start FastAPI.
3. Start Streamlit.
4. Ask for cloud migration readiness.
5. Show which tools the agent selected.
6. Ask for a migration/deployment action and show the approval gate.
7. Open `/docs`.
8. Run `pytest`.
9. Explain how `knowledge_search` can be replaced by the Day 1 Chroma RAG service.

## Best interview message
Use deterministic code for predictable operations and agents where dynamic reasoning or tool selection creates value.
