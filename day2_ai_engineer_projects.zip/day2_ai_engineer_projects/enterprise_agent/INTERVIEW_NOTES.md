# Day 2 Interview Notes

## Agent
An agent uses an LLM to reason about a goal, select tools, inspect results, and decide what to do next.

## Tool calling
The LLM does not receive unrestricted Python execution. It emits a structured tool request. Application code validates and executes the registered tool.

## Agent vs workflow
Use workflows when the sequence is known. Use agents when dynamic reasoning/tool selection provides value.

## Human-in-the-loop
High-impact actions such as deployment, deletion, financial decisions, or sensitive data changes should require explicit approval.

## Strong statement
"I don't use agents just because I can. I use deterministic code for predictable operations and agents where dynamic reasoning or tool selection creates business value."

## Likely questions
1. What is an AI agent?
2. Agent vs RAG?
3. Agent vs workflow?
4. What is tool calling?
5. How do you secure tools?
6. How do you prevent prompt injection?
7. How do you implement human-in-the-loop?
8. How do you evaluate an agent?
9. How do you control cost?
10. How would you deploy this to Azure?
11. How would you handle authentication?
12. How would you handle tool failures?
13. What happens when the LLM returns invalid JSON?
14. How would you scale the service?

## Day 1 + Day 2 extension
Replace `knowledge_search()` with the Day 1 Chroma RAG implementation. The resulting system becomes:

Streamlit -> FastAPI -> Agent -> {RAG, SQL, Inventory} -> Ollama -> Human approval
