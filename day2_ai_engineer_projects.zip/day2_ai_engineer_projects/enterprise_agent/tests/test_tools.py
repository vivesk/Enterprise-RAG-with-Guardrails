from app.tools import ToolRegistry


def test_registered_tools_exist():
    registry = ToolRegistry()
    assert "cloud_inventory" in registry.names()
    assert "risk_database" in registry.names()
    assert "knowledge_search" in registry.names()


def test_unknown_tool_is_rejected():
    registry = ToolRegistry()
    try:
        registry.execute("run_shell_command", {})
        assert False
    except ValueError:
        assert True


def test_risk_tool_returns_data():
    result = ToolRegistry().execute("risk_database", {"severity": "HIGH"})
    assert "Hardcoded credentials" in result.data
