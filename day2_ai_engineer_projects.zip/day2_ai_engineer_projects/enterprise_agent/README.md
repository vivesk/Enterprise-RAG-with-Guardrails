# Day 2 AI Engineer Interview Project

## Enterprise Research & Analysis Agent

Demonstrates AI agents, tool calling, FastAPI, structured outputs, RAG-ready architecture, SQL/data tools, human-in-the-loop, guardrails, Docker, Streamlit, and testing.

### Architecture

```text
Streamlit UI -> FastAPI -> Agent Service -> Ollama
                              |
                    +---------+---------+
                    |         |         |
                 Inventory   Risk     Knowledge
                   Tool      Tool       Tool
                    |         |         |
                   APIs      SQL       RAG
```

The LLM can select only registered tools. It cannot execute arbitrary Python or shell commands.

## Setup

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
pip install -r requirements.txt
ollama pull llama3.2:3b
```

Run API:
```bash
uvicorn app.main:app --reload
```

Run UI:
```bash
streamlit run app/streamlit_app.py
```

API docs: http://127.0.0.1:8000/docs

## Example

```bash
curl -X POST http://127.0.0.1:8000/analyze ^
  -H "Content-Type: application/json" ^
  -d "{"request":"Analyze cloud migration readiness and identify the top risks."}"
```

## Interview message

Use deterministic code for predictable operations and agents where dynamic reasoning or tool selection creates value.

Production additions: Entra ID/RBAC, Key Vault, audit logging, rate limiting, real search/API tools, managed vector search, tracing, evaluation, prompt/model versioning, and approval persistence.
