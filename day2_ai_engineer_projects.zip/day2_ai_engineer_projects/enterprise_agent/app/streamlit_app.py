import requests
import streamlit as st


st.title("Enterprise Research & Analysis Agent")
st.caption("Day 2 AI Engineer interview project")

api_url = st.sidebar.text_input("FastAPI URL", "http://127.0.0.1:8000")

request = st.text_area(
    "What should the AI agent analyze?",
    "Analyze the cloud migration readiness and identify the top risks.",
    height=120,
)

if st.button("Run Agent"):
    response = requests.post(
        f"{api_url}/analyze",
        json={"request": request},
        timeout=180,
    )

    if response.ok:
        result = response.json()
        st.markdown("## Analysis")
        st.write(result["answer"])

        st.markdown("## Agent Tool Calls")
        for call in result["tool_calls"]:
            st.json(call)

        if result["requires_approval"]:
            st.warning("Human approval required before any consequential action.")
            st.info(result["approval_reason"])
    else:
        st.error(response.text)
