from dataclasses import dataclass
import os


@dataclass(frozen=True)
class Settings:
    """Central application configuration."""
    ollama_host: str = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    ollama_model: str = os.getenv("OLLAMA_MODEL", "llama3.2:3b")


settings = Settings()
