import json
from ollama import Client

from .config import settings
from .models import ToolCall
from .tools import ToolRegistry


ROUTER_PROMPT = """
You are an enterprise AI agent router.

Allowed tools:
- cloud_inventory: inspect application/cloud inventory
- risk_database: inspect known risks
- knowledge_search: retrieve enterprise knowledge

Return ONLY valid JSON:
{"tool_calls":[{"tool":"tool_name","arguments":{}}]}

Use the minimum tools needed. Never invent tool names. Never request
shell commands, Python execution, deployment, deletion, or other actions.
"""

FINAL_PROMPT = """
You are an enterprise technology analysis assistant.
Use only the supplied tool results. Do not invent facts.
Clearly distinguish observed facts from recommendations.

Return:
1. Executive summary
2. Findings
3. Risks
4. Recommended next steps
5. Evidence used
"""


class AgentService:
    """LLM router + controlled tool execution + final synthesis."""

    def __init__(self) -> None:
        self.llm = Client(host=settings.ollama_host)
        self.tools = ToolRegistry()

    def _route(self, request: str) -> list[ToolCall]:
        """Ask the LLM which registered tools are relevant."""
        response = self.llm.chat(
            model=settings.ollama_model,
            messages=[
                {"role": "system", "content": ROUTER_PROMPT},
                {"role": "user", "content": request},
            ],
        )
        raw = response["message"]["content"]
        parsed = json.loads(raw)
        calls = []
        for call in parsed.get("tool_calls", []):
            name = call.get("tool")
            if name not in self.tools.names():
                raise ValueError(f"Unauthorized tool requested: {name}")
            calls.append(ToolCall(tool=name, arguments=call.get("arguments", {})))
        return calls

    def analyze(self, request: str) -> dict:
        """Route, execute tools, then synthesize the final analysis."""
        calls = self._route(request)
        results = []
        for call in calls:
            result = self.tools.execute(call.tool, call.arguments)
            results.append({"tool": result.tool, "data": result.data})

        final = self.llm.chat(
            model=settings.ollama_model,
            messages=[
                {"role": "system", "content": FINAL_PROMPT},
                {"role": "user", "content": f"REQUEST:\n{request}\n\nTOOL RESULTS:\n{json.dumps(results, indent=2)}"},
            ],
        )

        requires_approval = any(
            word in request.lower()
            for word in ["execute", "deploy", "delete", "migrate"]
        )

        return {
            "answer": final["message"]["content"],
            "tool_calls": [c.model_dump() for c in calls],
            "requires_approval": requires_approval,
            "approval_reason": (
                "A potentially consequential action was requested; "
                "human approval is required before execution."
                if requires_approval else None
            ),
        }
