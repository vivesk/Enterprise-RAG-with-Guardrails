from typing import Any
from pydantic import BaseModel, Field


class AnalyzeRequest(BaseModel):
    """Input sent to the agent."""
    request: str = Field(min_length=5, max_length=4000)


class ToolCall(BaseModel):
    """Auditable record of an agent tool selection."""
    tool: str
    arguments: dict[str, Any] = {}


class AnalysisResponse(BaseModel):
    """Final analysis returned by the API."""
    answer: str
    tool_calls: list[ToolCall]
    requires_approval: bool
    approval_reason: str | None = None
