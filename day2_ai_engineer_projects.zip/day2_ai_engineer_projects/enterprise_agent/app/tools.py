from dataclasses import dataclass
import sqlite3


@dataclass
class ToolResult:
    """Standard result envelope returned by a tool."""
    tool: str
    data: str


class ToolRegistry:
    """Allow-list of tools available to the LLM.

    The model can request these tools, but application code validates and
    executes them. The model never receives arbitrary code execution.
    """

    def __init__(self) -> None:
        self._tools = {
            "cloud_inventory": self.cloud_inventory,
            "risk_database": self.risk_database,
            "knowledge_search": self.knowledge_search,
        }

    def names(self) -> list[str]:
        return list(self._tools)

    def execute(self, name: str, arguments: dict) -> ToolResult:
        if name not in self._tools:
            raise ValueError(f"Tool '{name}' is not permitted.")
        return self._tools[name](arguments)

    def cloud_inventory(self, arguments: dict) -> ToolResult:
        """Return deterministic application inventory data."""
        services = [
            {"name": "Customer API", "runtime": "Python", "database": "PostgreSQL", "deployment": "VM", "criticality": "High"},
            {"name": "Batch Processor", "runtime": "Python", "database": "PostgreSQL", "deployment": "VM", "criticality": "Medium"},
            {"name": "Reporting Portal", "runtime": "React", "database": "SQL Server", "deployment": "VM", "criticality": "Medium"},
        ]
        service = arguments.get("service", "all")
        if service != "all":
            services = [s for s in services if service.lower() in s["name"].lower()]
        return ToolResult("cloud_inventory", str({"services": services}))

    def risk_database(self, arguments: dict) -> ToolResult:
        """Read a small in-memory SQLite risk register."""
        conn = sqlite3.connect(":memory:")
        cur = conn.cursor()
        cur.execute("CREATE TABLE risks (id INTEGER, description TEXT, severity TEXT, owner TEXT)")
        cur.executemany(
            "INSERT INTO risks VALUES (?, ?, ?, ?)",
            [
                (1, "Hardcoded credentials detected", "HIGH", "Security"),
                (2, "Unsupported runtime version", "MEDIUM", "Engineering"),
                (3, "Manual deployment process", "MEDIUM", "Operations"),
                (4, "No disaster recovery test", "HIGH", "Infrastructure"),
            ],
        )
        severity = arguments.get("severity")
        if severity:
            cur.execute("SELECT * FROM risks WHERE severity = ?", (severity.upper(),))
        else:
            cur.execute("SELECT * FROM risks")
        rows = cur.fetchall()
        conn.close()
        return ToolResult("risk_database", str(rows))

    def knowledge_search(self, arguments: dict) -> ToolResult:
        """Return demo enterprise knowledge.

        Replace this implementation with the Day 1 Chroma RAG service.
        """
        query = arguments.get("query", "").lower()
        knowledge = {
            "containerization": "Containerization packages dependencies into portable images and supports consistent deployment.",
            "managed database": "Managed databases reduce infrastructure administration and can provide backups, monitoring and high availability.",
            "migration": "A cloud migration typically includes discovery, assessment, modernization, testing, cutover and post-migration optimization.",
        }
        matches = [v for k, v in knowledge.items() if k in query] or list(knowledge.values())
        return ToolResult("knowledge_search", " ".join(matches))
