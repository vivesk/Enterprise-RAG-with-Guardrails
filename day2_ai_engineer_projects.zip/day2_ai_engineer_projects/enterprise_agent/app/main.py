import json

from fastapi import FastAPI, HTTPException

from .agent import AgentService
from .models import AnalyzeRequest, AnalysisResponse


app = FastAPI(
    title="Enterprise Research & Analysis Agent",
    description="Day 2 AI Engineer interview project.",
    version="1.0.0",
)

agent = AgentService()


@app.get("/health")
def health() -> dict:
    """Health check for deployment/load balancers."""
    return {"status": "ok"}


@app.get("/tools")
def tools() -> dict:
    """Show the allow-listed tools."""
    return {"tools": agent.tools.names()}


@app.post("/analyze", response_model=AnalysisResponse)
def analyze(request: AnalyzeRequest) -> AnalysisResponse:
    """Run the agent against an enterprise analysis request."""
    try:
        return AnalysisResponse(**agent.analyze(request.request))
    except (ValueError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
